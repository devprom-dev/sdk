<?php

$plugin_text_array = array 
(
 		1 => 'Taskombank extendend functionality'
);
